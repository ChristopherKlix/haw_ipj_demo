import datetime as dt


EXPIRATION_DATE = dt.datetime(2023, 11, 27, 0, 0, 0)
# EXPIRATION_DATE = dt.datetime(2022, 11, 27, 0, 0, 0)
