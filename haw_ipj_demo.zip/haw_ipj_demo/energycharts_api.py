# Example:
# 'https://api.energy-charts.info/total_power?country=de&start=2023-01-01T00%3A00%2B01%3A00&end=2023-01-01T23%3A45%2B01%3A00'

from dataclasses import dataclass, field
import sys
import requests
import datetime as dt
import json
import pandas as pd
import csv
import numpy as np


BASE_URL = 'https://api.energy-charts.info'
POWER = '/total_power'
LOCALE = '?country=de'
START_PREFIX = '&start='
END_PREFIX = '&end='

RES_PATH = './src/static/res/'


def main():
    # Clear screen
    print('\033[H\033[J')

    # Get CLI args
    args = sys.argv[1:]

    # Check if first argument is schema
    if len(args) > 0 and args[0] == 'schema':
        schema_test_file()
        quit(0)
    elif len(args) > 0 and args[0] == 'parse':
        create_data_array()
        quit(0)

    start: dt.datetime = dt.datetime(2015, 1, 1, 0, 0)
    end: dt.datetime = dt.datetime(2022, 12, 31, 23, 59)

    filename: str = 'energycharts.json'

    perform_request(start, end, filename)

    create_csv(filename)


def perform_request(start: dt.datetime, end: dt.datetime, filename: str) -> float:
    """
    Performs a request to the energycharts API and writes the response to a file.

    Args:
        start (dt.datetime): The start datetime of the requested data.
        end (dt.datetime): The end datetime of the requested data.
        filename (str): The name of the file to write the response to.

    Returns:
        float: The time elapsed during the API request.
    """

    print(f'Requesting data from {BASE_URL}...')

    print(f'Endpoint: {POWER}')
    print(f'Locale:   {LOCALE}')
    print(f'Start:    {start}')
    print(f'End:      {end}')

    print('-' * 50)

    # Convert dt.datetime(2023, 01, 01, 00, 00) to '2023-01-01T00%3A00%2B01%3A00'
    start_str: str = start.strftime('%Y-%m-%dT%H%%3A%M%%2B01%%3A00')
    end_str: str = end.strftime('%Y-%m-%dT%H%%3A%M%%2B01%%3A00')

    url: str = BASE_URL + POWER + LOCALE + START_PREFIX + start_str + END_PREFIX + end_str

    print(f'CURL:     {url}')
    print('# requesting...')

    # Perform request
    timestamp_0: dt.datetime = dt.datetime.now()

    response: requests.Response = requests.get(url)

    timestamp_1: dt.datetime = dt.datetime.now()

    time_elapsed: dt.timedelta = timestamp_1 - timestamp_0

    print(f'# API request time: {time_elapsed}')

    if response.status_code != 200:
        print('API invalid request.')
        quit(1)

    print('# Data successfully received.')
    print('-' * 50)

    print('Writing data into file...')

    # Write json into file
    with open(f'{RES_PATH}{filename}', 'w', encoding='utf-8') as file:
        json.dump(response.json(), file, ensure_ascii=False, indent=4)

    print('Data successfully written into file.')

    return time_elapsed


def schema_test_file() -> None:
    """
    Creates a schema test file by performing a request to the energy charts API and saving the response to a JSON file.
    Then, it creates a CSV file from the JSON file.

    Args:
        None

    Returns:
        None
    """

    print('Creating schema test file...')

    json_filename = 'energycharts_schema_test.json'

    start: dt.datetime = dt.datetime(2023, 1, 1, 0, 0)
    end: dt.datetime = dt.datetime(2023, 1, 1, 0, 59)

    perform_request(start, end, json_filename)

    print('Schema test file successfully created.')

    create_csv(json_filename)


def create_csv(srcfile: str, filename: str | None=None) -> None:
    """
    Reads a JSON file containing energy production data and converts it to a CSV file.

    Args:
        srcfile (str): The name of the JSON file to read.
        filename (str, optional): The name of the CSV file to create. If not provided, the CSV file will have the same name as the JSON file with a .csv extension.

    Returns:
        None
    """

    print('Creating CSV file...')

    with open(f'{RES_PATH}{srcfile}', 'r', encoding='utf-8') as file:
        data = json.load(file)

        # Convert the JSON data to a DataFrame
        # df = pd.json_normalize(data, )
        df_list = []

        for pt in data['production_types']:
            df = pd.DataFrame(pt['data'], columns=[pt['name']], index=data['unix_seconds'])
            df_list.append(df)

        df_final = pd.concat(df_list, axis=1)

        # Reset the index and rename the index column
        df_final.reset_index(inplace=True)
        df_final.rename(columns={'index': 'unix_seconds'}, inplace=True)

        # Save the DataFrame to a CSV file
        if filename is None:
            filename = f'{srcfile.replace(".json", ".csv")}'

        df_final.to_csv(f'{RES_PATH}{filename}', index=False)

    print('CSV file successfully created.')


@dataclass
class Data:
    start: dt.datetime             = field(default=None, init=True, kw_only=True)
    end: dt.datetime               = field(default=None, init=False)

    def __post_init__(self) -> None:
        self.end = self.start + dt.timedelta(minutes=15)
        # self.production = self.Production()
        # self.power = self.Power()
        # self.consumption = self.Consumption()

    @dataclass
    class Production:
        pv: float                  = field(default=0.0, init=True, kw_only=True)
        wind_offshore: float       = field(default=0.0, init=True, kw_only=True)
        wind_onshore: float        = field(default=0.0, init=True, kw_only=True)
        biomass: float             = field(default=0.0, init=True, kw_only=True)
        hydro: float               = field(default=0.0, init=True, kw_only=True)
        other_renewables: float    = field(default=0.0, init=True, kw_only=True)
        coal: float                = field(default=0.0, init=True, kw_only=True)
        lignite: float             = field(default=0.0, init=True, kw_only=True)
        gas: float                 = field(default=0.0, init=True, kw_only=True)
        other_conventionals: float = field(default=0.0, init=True, kw_only=True)
        nuclear: float             = field(default=0.0, init=True, kw_only=True)

    production: Production         = field(default=Production, init=False)

    @dataclass
    class Power:
        pv: float                  = field(default=0.0, init=True, kw_only=True)
        wind_offshore: float       = field(default=0.0, init=True, kw_only=True)
        wind_onshore: float        = field(default=0.0, init=True, kw_only=True)
        biomass: float             = field(default=0.0, init=True, kw_only=True)
        hydro: float               = field(default=0.0, init=True, kw_only=True)
        other_renewables: float    = field(default=0.0, init=True, kw_only=True)
        coal: float                = field(default=0.0, init=True, kw_only=True)
        lignite: float             = field(default=0.0, init=True, kw_only=True)
        gas: float                 = field(default=0.0, init=True, kw_only=True)
        other_conventionals: float = field(default=0.0, init=True, kw_only=True)
        nuclear: float             = field(default=0.0, init=True, kw_only=True)

    power: Power                   = field(default=Power, init=False)

    @dataclass
    class Consumption:
        load: float                = field(default=0.0, init=True, kw_only=True)
        residual: float            = field(default=0.0, init=True, kw_only=True)

    consumption: Consumption       = field(default=Consumption, init=False)


def init_energycharts(vals: dict) -> Data:
    start = dt.datetime.fromtimestamp(int(vals['unix_seconds']))
    data = Data(start=start)

    try:
        data.production.pv = vals['Solar']
        data.production.wind_offshore = vals['Wind offshore']
        data.production.wind_onshore = vals['Wind onshore']
        data.production.biomass = vals['Biomass']
        data.production.hydro = vals['Hydro Run-of-River'] + vals['Hydro water reservoir']
        data.production.other_renewables = vals['Geothermal']
        data.production.coal = vals['Fossil hard coal']
        data.production.lignite = vals['Fossil brown coal / lignite']
        data.production.gas = vals['Fossil gas']
        data.production.other_conventional = vals['Fossil oil'] + vals['Others'] + vals['Waste']
        data.production.nuclear = vals['Nuclear']
    except KeyError as e:
        print(f'KeyError: {e}')
    finally:
        return data


def create_data_array() -> Data:
    srcfile = 'energycharts_schema_test.csv'

    data = np.empty(4, dtype=Data)

    with open(f'{RES_PATH}{srcfile}', 'r', encoding='utf-8') as file:
        reader = csv.DictReader(file)

        for row in reader:
            data = np.append(data, init_energycharts(row))

    print(data)

    return data


if __name__ == "__main__":
    main()
