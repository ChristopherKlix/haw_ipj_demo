import streamlit as st
import datetime as dt
import pandas as pd
import numpy as np
import altair as alt

import init_page

from dtypes import View
from data import Data


class IST_View:
    def __init__(self):
        print("IST_View init")

        self.start_date = dt.datetime(2015, 1, 1, 0, 0)
        self.end_date = dt.datetime(2022, 12, 31, 0, 0)

    def render(self):
        self.page = init_page.PageLoader()
        data = self.page.get_data()

        st.title("Ist-Zustand")

        st.markdown('''
                    <div id="background-image">
                        <div id="background-image__content">
                        </div>
                    </div>
                    ''', unsafe_allow_html=True)

        with open("./static/background.css", "r") as file:
            css = file.read()
            st.markdown(f'<style>{css}</style>', unsafe_allow_html=True)




        with st.expander("🛠️ Parameter", expanded=True):
            self.render_param_view()

        self.render_plot_view()

    def render_param_view(self):
        columns = st.columns(3)

        min_date = dt.date(2020, 1, 1)
        max_date = dt.date(2022, 12, 31)

        self.intervals = {
            'total': 'Gesamt',
            'year': 'Jahr',
            'month': 'Monat',
            'day': 'Tag',
        }

        with columns[0]:
            self.selection_interval = st.selectbox(
                label='Interval',
                options=self.intervals.values(),
                index=0,
                help="The data is available from 01.01.2020 to 31.12.2022."
                )

            if self.selection_interval == self.intervals.get('total'):
                self.start_date = dt.datetime(2020, 1, 1, 0, 0)
                self.end_date = dt.datetime(2022, 12, 31, 23, 59)

        with columns[1]:
            if self.selection_interval == self.intervals.get('year'):
                interval_selection_year = st.selectbox(
                    label='Year',
                    options=[2015, 2016, 2017, 2018, 2019, 2020, 2021, 2022],
                    index=7,
                    disabled=(self.selection_interval == self.intervals.get('total'))
                    )

                if interval_selection_year:
                    self.start_date = dt.datetime(interval_selection_year, 1, 1, 0, 0)
                    self.end_date = dt.datetime(interval_selection_year, 12, 31, 23, 59)
            elif self.selection_interval == self.intervals.get('month'):

                columns_month = st.columns(2)

                with columns_month[0]:
                    interval_selection_month = st.selectbox(
                        label='Monat',
                        options=['Januar', 'Februar', 'März', 'April', 'Mai', 'Juni', 'Juli', 'August',
                                'September', 'Oktober', 'November', 'Dezember'],
                        index=0,
                        help="The data is available from 01.01.2020 to 31.12.2022."
                        )

                with columns_month[1]:
                    interval_selection_year = st.selectbox(
                        label='Jahr',
                        options=[2015, 2016, 2017, 2018, 2019, 2020, 2021, 2022],
                        index=7,
                        disabled=(self.selection_interval == self.intervals.get('total'))
                        )

                if interval_selection_month:
                    self.start_date = dt.datetime(interval_selection_year, self.month_to_index(interval_selection_month), 1, 0, 0)

                    next_month = self.month_to_index(interval_selection_month)+1
                    if next_month > 12:
                        next_month = 1
                        interval_selection_year += 1
                    self.end_date = dt.datetime(interval_selection_year, next_month, 1, 23, 59)
            elif self.selection_interval == self.intervals.get('day'):
                selected_start_date = st.date_input(
                    label="Select a date to plot",
                    value=dt.date(2020, 1, 1),
                    min_value=min_date,
                    max_value=max_date,
                    format="DD.MM.YYYY",
                    key='date_input',
                    help="The data is available from 01.01.2020 to 31.12.2022.",
                    disabled=(self.selection_interval == self.intervals.get('total'))
                )

                if selected_start_date:
                    self.start_date = dt.datetime(selected_start_date.year, selected_start_date.month, selected_start_date.day, 0, 0)
                    self.end_date = dt.datetime(selected_start_date.year, selected_start_date.month, selected_start_date.day, 23, 59)
            else:
                st.date_input(
                    label="Select a date to plot",
                    value=(dt.date(2015, 1, 1), dt.date(2022, 12, 31)),
                    format="DD.MM.YYYY",
                    key='date_input',
                    help="The data is available from 01.01.2020 to 31.12.2022.",
                    disabled=(self.selection_interval == self.intervals.get('total'))
                )

        with columns[2]:
            st.selectbox(
                label='Data source',
                index=0,
                options=["SMARD.de", "Frauenhofer", "Agora Energiewende"]
            )

        columns_range = st.columns(3)

        with columns_range[0]:
            plot_selection = st.selectbox(
                label='Plots',
                options=["Energieerzeugung", "Installierte Leistung", "Verbrauch"]
            )

        with columns_range[1]:
            source_selection = st.selectbox(
                label='Energiequellen',
                options=["Alle", "Nur Erneuerbare", "Nur Fossile", "Benutzerdefiniert"],
                help="Only show the renewable energy sources.",
            )

        self.selected_energy_sources = st.multiselect(
            label='Energiequellen',
            options=["Wind Offshore", "Wind Onshore", "Photovoltaik", "Hydro", "Biomasse", "Steinkohle", "Braunkohle", "Gas", "Andere Erneuerbare", "Andere Konventionelle", "Nuclear"],
            default=["Wind Offshore", "Wind Onshore", "Photovoltaik", "Hydro", "Biomasse", "Steinkohle", "Braunkohle", "Gas", "Andere Erneuerbare", "Andere Konventionelle", "Nuclear"],
            disabled=plot_selection is "Verbrauch" or source_selection is not "Benutzerdefiniert",
            placeholder="Keine Energiequelle ausgewählt"
            )

        self.time_range_resolution = 20
        # self.time_range_resolution = st.select_slider('Data Point Auflösung (jeder n-th data point wird angezeigt)',
        #                                         options=[1, 10, 20, 50, 100, 200, 500, 1_000, 10_000],
        #                                         value=20,
        #                                         key='time_range_resolution',
        #                                         help='The resolution of the time range. The higher the value, the less data points are displayed. This can help with performance issues.')
        # st.caption(f'The time range resolution determines how many data points are displayed. The higher the value, the less data points are displayed. This can help with performance issues but also reduces the accuracy of the data.')


    def render_plot_view(self):
        st.markdown('### Plot')

        # View.demo_chart()

        if self.selection_interval == self.intervals.get('total') or self.selection_interval == self.intervals.get('year') or self.selection_interval == self.intervals.get('month') or self.selection_interval == self.intervals.get('day'):
            # Bar chart with monthly data

            # Retrieve raw data
            raw_data = self.page.get_data()[0]

            # Find the start and end data
            i_y = self.start_date.year - 2020
            i_m = self.start_date.month - 1
            i_d = self.start_date.day - 1
            first_element: Data = raw_data[i_y, i_m, i_d, 0, 0]

            i_y = self.end_date.year - 2020
            i_m = self.end_date.month - 1
            i_d = self.end_date.day - 1
            last_element: Data = raw_data[i_y, i_m, i_d, 23, 3]

            # Flatten the data
            raw_data = raw_data.flatten()

            # Find the indices of the start and end data
            first_index = np.where(raw_data == first_element)
            last_index = np.where(raw_data == last_element)

            # Select the data between the start and end indices
            selected_data = raw_data[first_index[0][0]:last_index[0][0]+1]

            # Filter out the None values
            mask = np.array([item.start is not None for item in selected_data])
            filtered_data = selected_data[mask]

            # Create a time range
            energy_time_range = pd.date_range(
                start=self.start_date.strftime("%Y-%m-%d %H:%M"),
                end=self.end_date.strftime("%Y-%m-%d %H:%M"),
                freq='15min',
                tz='Europe/Berlin'
            )

            # Convert from Wh to TWh
            if self.selection_interval == self.intervals.get('day'):
                filtered_data /= 1_000_000_000
                y_axis_scale = "GWh"
            else:
                filtered_data /= 1_000_000_000_000
                y_axis_scale = "TWh"

            # Create a dataframe
            energy = {
                'Date': energy_time_range,
            }

            if 'Photovoltaik' in self.selected_energy_sources:
                energy['Photovoltaik'] = [d.pv for d in filtered_data]

            if 'Wind Offshore' in self.selected_energy_sources:
                energy['Wind Offshore'] = [d.wind_offshore for d in filtered_data]

            if 'Wind Onshore' in self.selected_energy_sources:
                energy['Wind Onshore'] = [d.wind_onshore for d in filtered_data]

            if 'Hydro' in self.selected_energy_sources:
                energy['Hydro'] = [d.hydro for d in filtered_data]

            if 'Biomasse' in self.selected_energy_sources:
                energy['Biomasse'] = [d.biomass for d in filtered_data]

            if 'Steinkohle' in self.selected_energy_sources:
                energy['Steinkohle'] = [d.coal for d in filtered_data]

            if 'Braunkohle' in self.selected_energy_sources:
                energy['Braunkohle'] = [d.charcoal for d in filtered_data]

            if 'Gas' in self.selected_energy_sources:
                energy['Gas'] = [d.gas for d in filtered_data]

            if 'Andere Erneuerbare' in self.selected_energy_sources:
                energy['Andere Erneuerbare'] = [d.other_renewables for d in filtered_data]

            if 'Andere Konventionelle' in self.selected_energy_sources:
                energy['Andere Konventionelle'] = [d.other_conventional for d in filtered_data]

            if 'Nuclear' in self.selected_energy_sources:
                energy['Atomkraft'] = [d.nuclear for d in filtered_data]

            energy_df = pd.DataFrame(energy)

            columns_mode = st.columns([2, 2, 2])

            with columns_mode[0]:
                mode = st.selectbox(
                    label='Absolut / Relativ',
                    options=["Absolut", "Relativ"],
                    index=0,
                    help="Absolut zeigt die Werte und relativ setzt diese im Vergleich zu der Gesamterzeugung pro Monat."
                )

            if self.selection_interval == self.intervals.get('total'):
                with columns_mode[1]:
                    sum_mode = st.selectbox(
                        label='Summe',
                        options=["Monat", "Jahr"],
                        index=0,
                        help="Die Summe der Energieerzeugung pro Monat oder Jahr."
                    )

            with columns_mode[2]:
                show_legend = st.selectbox(
                    label='Legende anzeigen',
                    options=["True", "False"],
                    index=0,
                    help="Zeigt die Legende an."
                )

            # Group and sum the data by month
            energy_df['Date'] = pd.to_datetime(energy_df['Date'])

            if self.selection_interval == self.intervals.get('total'):
                if sum_mode == "Monat":
                    energy_df['Date'] = energy_df['Date'].dt.strftime('%Y-%m')
                elif sum_mode == "Jahr":
                    energy_df['Date'] = energy_df['Date'].dt.strftime('%Y')
            elif self.selection_interval == self.intervals.get('year'):
                energy_df['Date'] = energy_df['Date'].dt.strftime('%Y-%m')
            elif self.selection_interval == self.intervals.get('month'):
                energy_df['Date'] = energy_df['Date'].dt.strftime('%Y-%m-%d')
            elif self.selection_interval == self.intervals.get('day'):
                energy_df['Date'] = energy_df['Date'].dt.strftime('%Y-%m-%d %H:%M')
            energy_df = energy_df.groupby(['Date']).sum().reset_index()

            # Melt the dataframe
            energy_df_melted = pd.melt(energy_df, id_vars=["Date"], var_name="Energy_Source", value_name="Energy Value")

            # Create the chart
            if self.selection_interval == self.intervals.get('day'):
                chart = alt.Chart(energy_df_melted).mark_area()
            else:
                chart = alt.Chart(energy_df_melted).mark_bar()

            energy_order = [
                'Andere Konventionelle',
                'Steinkohle',
                'Braunkohle',
                'Gas',
                'Atomkraft',
                'Andere Erneuerbare',
                'Hydro',
                'Biomasse',
                'Wind Offshore',
                'Wind Onshore',
                'Photovoltaik',
            ]

            energy_color = {
                'Photovoltaik': '#f2b134',
                'Wind Onshore': '#17B890',
                'Wind Offshore': '#3454D1',
                'Biomasse': '#7DDF64',
                'Hydro': '#63D2FF',
                'Andere Erneuerbare': '#00a0dc',
                'Atomkraft': '#0CCA4A',
                'Gas': '#FFE0B5',
                'Braunkohle': '#8A6552',
                'Steinkohle': '#CDD4DF',
                'Andere Konventionelle': '#6D5F6D',
            }

            custom_order = '{'

            for i, energy_source in enumerate(energy_order):
                custom_order += f"'{energy_source}': {i}, "

            custom_order += '}'

            chart = chart.transform_calculate(
                order=f'{custom_order}[datum.Energy_Source]'
            )

            chart = chart.encode(
                x=alt.X(
                    'Date:O',
                    axis=alt.Axis(title='Datum [M]')
                ),
                y=alt.Y(
                    'sum(Energy Value):Q',
                    stack=("normalize" if mode == "Relativ" else 'zero'),
                    axis=alt.Axis(title=f'Energieerzeugung [{y_axis_scale}]'),
                ),
                color=alt.Color(
                    'Energy_Source:N',
                    # sort=alt.SortField("order", "ascending"),
                    scale=alt.Scale(domain=list(energy_color.keys()), range=list(energy_color.values())),
                    legend=(alt.Legend(title='Energy Source') if show_legend == "True" else None),
                ),
                order='order:O',
                tooltip=['Energy_Source', 'Date', 'Energy Value']
            ).properties(
                height=500,
                title='Stacked Bar Chart of Energy Sources'
            ).configure_legend(
                labelFontSize=12,
                titleFontSize=14
            )

            st.altair_chart(chart, use_container_width=True)

    def month_to_index(self, month: str) -> int:
        return {
            'Januar': 1,
            'Februar': 2,
            'März': 3,
            'April': 4,
            'Mai': 5,
            'Juni': 6,
            'Juli': 7,
            'August': 8,
            'September': 9,
            'Oktober': 10,
            'November': 11,
            'Dezember': 12
        }.get(month, 0)


if __name__ == "__main__":
    view = IST_View()
    view.render()
