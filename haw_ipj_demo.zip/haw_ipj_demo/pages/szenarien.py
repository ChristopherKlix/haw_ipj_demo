import streamlit as st

import init_page
from dtypes import View, URLImage


class Szenarien_View:
    def __init__(self):
        print("Szenarien_View init")

    def render(self):
        page = init_page.PageLoader(layout="wide")
        data = page.get_data()

        st.title("Szenarien")

        scenarios = {
            'default': "📊 Referenz Szenario (empfohlen)",
            'best-case': "☀️ Szenario \"Best Case\"",
            'worst-case': "🌧️ Szenario \"Worst Case\"",
            'custom': "⚙️ Benuzterdefiniertes Szenario"
        }


        # ---------------
        # ! Hero
        # ---------------
        columns_hero_section = st.columns(2, gap='medium')

        with columns_hero_section[0]:
            container_hero_left = st.container()

        with columns_hero_section[1]:
            container_hero_right = st.container()

        # ---------------
        # ! Hero section left
        # ---------------
        with container_hero_left:
            View.image(
                URLImage(
                    url="https://images.pexels.com/photos/2561628/pexels-photo-2561628.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
                    alt="Climate Protest",
                )
            )

        # ---------------
        # ! Hero section right
        # ---------------
        with container_hero_right:

            cols_scenario_simulate = st.columns([3, 2])

            with cols_scenario_simulate[0]:
                st.markdown('#### Szenario auswählen')

                param_scenario = st.selectbox(
                    label="Szenario",
                    options=scenarios.values(),
                )

            if param_scenario == "📊 Referenz Szenario (empfohlen)":
                st.markdown('''
                            Das Referenzszenario ist das wahrscheinlichste Szenario für das Jahr 2030.
                            Es basiert auf den aktuellen politischen und wirtschaftlichen Rahmenbedingungen.
                            Zudem wird davon ausgegangen, dass die Klimaziele erreicht werden.
                            Vorgegebene installierte Leistung wie vom BMWK vorgesehen werden erreicht und die Wetterbedingungen sind durchschnittlich.
                            ''')
            elif param_scenario == "☀️ Szenario \"Best Case\"":
                st.markdown('''
                            Das Best Case Szenario ist das optimistischste Szenario für das Jahr 2030.
                            Es basiert auf den aktuellen politischen und wirtschaftlichen Rahmenbedingungen.
                            Zudem wird davon ausgegangen, dass die Klimaziele erreicht werden.
                            Vorgegebene installierte Leistung wie vom BMWK vorgesehen werden erreicht und die Wetterbedingungen sind optimal.
                            ''')
            elif param_scenario == "🌧️ Szenario \"Worst Case\"":
                st.markdown('''
                            Das Worst Case Szenario ist das pessimistischste Szenario für das Jahr 2030.
                            Es basiert auf den aktuellen politischen und wirtschaftlichen Rahmenbedingungen.
                            Zudem wird davon ausgegangen, dass die Klimaziele nicht erreicht werden.
                            Vorgegebene installierte Leistung wie vom BMWK vorgesehen werden nicht erreicht und die Wetterbedingungen sind schlecht.
                            ''')
            elif param_scenario == "⚙️ Benuzterdefiniertes Szenario":
                st.markdown('''
                            Das benutzerdefinierte Szenario ermöglicht es, die Parameter für die Simulation selbst anzupassen.
                            So kann z.B. die installierte Leistung für Photovoltaik, Wind Offshore und Wind Onshore selbst festgelegt werden.
                            Zudem kann die Erzeugungseffizienz für Photovoltaik, Wind Offshore und Wind Onshore selbst festgelegt werden.
                            ''')
                st.caption('''
                           Die Parameter können im Abschnitt "Szenario Parameter" angepasst werden.
                            ''')

            # ---------------
            # ! Simulation Button
            # ---------------
            st.button(
                label="Simulation starten",
                help="Simulate the energy production and consumption for the selected scenario.",
                type="primary",
            )


        # ---------------
        # ! Parameters
        # ---------------

        if param_scenario == scenarios.get('custom'):
            self.render_parameter_view()

        # ---------------
        # ! Footer
        # ---------------
        self.render_footer_view()

    def render_parameter_view(self):
        st.divider()

        st.markdown('#### ⚙️ Szenario Parameter')
        st.markdown('''
                    Hier können die Parameter für das benutzerdefinierte Szenario angepasst werden.
                    ''')

        cols_params_row0 = st.columns(2, gap='medium')

        with cols_params_row0[0]:
            container_efficiency = st.container()

        with cols_params_row0[1]:
            container_capacity = st.container()

        cols_params_row1 = st.columns(2, gap='medium')

        with cols_params_row1[0]:
            container_consumption = st.container()

        with cols_params_row1[1]:
            View.image(
                URLImage(
                    url="https://images.pexels.com/photos/1473673/pexels-photo-1473673.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
                    alt="Dubai at night",
                )
            )

        st.divider()

        cols_params_row2 = st.columns(2, gap='medium')

        with cols_params_row2[0]:
            container_storage = st.container()

        with cols_params_row2[1]:
            st.write("Hier kommt der Müll hin.")

        with container_efficiency:
            self.render_efficiency_view()

        with container_capacity:
            self.render_capacity_view()

        with container_consumption:
            self.render_consumption_view()

        with container_storage:
            self.render_storage_view()

    def render_efficiency_view(self):
        st.markdown('#### ⚡ Erzeugungseffizienz')

        st.markdown('''
                    Die Erzeugungseffizienz gibt an, wie viel Prozent der installierten Leistung tatsächlich erzeugt wird.
                    Dieser Wert kann je nach Wetterbedingungen variieren.
                    Die Simulation berechnet einen erwarten Wert für das Jahr 2030.
                    Mit den Slidern kann dieser Wert prozentual nach oben oder unten angepasst werden.
                    ''')
        with st.expander(label="Wie beeinflusst dieser Parameter die Simulation?"):
            st.caption('''
                    Die Effizienz ist ein Kennwert, welcher in der Simulation eine Vielzahl von Faktoren berücksichtigt.
                    So beeinflusst der Faktor die simulierte Wetterbedingungen, die Anzahl der Sonnenstunden, die Anzahl der Windstunden, die Anzahl der Wolkenstunden, etc.
                    Daher dient dieser Wert als Prozentuale Angabe, mit Abweichung vom simulierten wahrscheinlichen Referenzjahr in 2030.
                    ''')

        st.caption('100% entspricht dem Refernzjahr 2030.')

        cols_efficiency = st.columns(3)

        with cols_efficiency[0]:
            param_efficiency_pv = st.slider(
                label="Photovoltaik [%]",
                min_value=0,
                max_value=200,
                value=100,
                help="100% entspricht dem Refernzjahr 2030.",
            )

            st.caption(f'Vorraussichtliche Erzeugung: {param_efficiency_pv / 100 * 196} TWh')

        with cols_efficiency[1]:
            param_efficieny_wind_off = st.slider(
                label="Wind Offshore [%]",
                min_value=0,
                max_value=200,
                value=100,
                help="100% entspricht dem Refernzjahr 2030.",
            )

            st.caption(f'Vorraussichtliche Erzeugung: {param_efficieny_wind_off / 100 * 196} TWh')

        with cols_efficiency[2]:
            param_efficieny_wind_on = st.slider(
                label="Wind Onshore [%]",
                min_value=0,
                max_value=200,
                value=100,
                help="100% entspricht dem Refernzjahr 2030.",
            )

            st.caption(f'Vorraussichtliche Erzeugung: {param_efficieny_wind_on / 100 * 196} TWh')

    def render_capacity_view(self):
        st.markdown('#### 🏗️ Installierte Leistung')

        st.markdown('''
                    Die Erzeugungseffizienz gibt an, wie viel Prozent der installierten Leistung tatsächlich erzeugt wird.
                    Dieser Wert kann je nach Wetterbedingungen variieren.
                    Die Simulation berechnet einen erwarten Wert für das Jahr 2030.
                    Mit den Slidern kann dieser Wert prozentual nach oben oder unten angepasst werden.
                    ''')
        with st.expander(label="Wie beeinflusst dieser Parameter die Simulation?"):
            st.caption('''
                    Die Effizienz ist ein Kennwert, welcher in der Simulation eine Vielzahl von Faktoren berücksichtigt.
                    So beeinflusst der Faktor die simulierte Wetterbedingungen, die Anzahl der Sonnenstunden, die Anzahl der Windstunden, die Anzahl der Wolkenstunden, etc.
                    Daher dient dieser Wert als Prozentuale Angabe, mit Abweichung vom simulierten wahrscheinlichen Referenzjahr in 2030.
                    ''')

        cols_capacity = st.columns(3)

        with cols_capacity[0]:
            st.number_input(
                label="Photovoltaik [GW]",
                min_value=0,
                max_value=1_000,
                value=240,
            )

        with cols_capacity[1]:
            st.number_input(
                label="Wind Offshore [GW]",
                min_value=0,
                max_value=1_000,
                value=240,
            )

        with cols_capacity[2]:
            st.number_input(
                label="Wind Onshore [GW]",
                min_value=0,
                max_value=1_000,
                value=240,
            )

    def render_consumption_view(self):
        st.markdown('#### 🔌 Stromverbrauch')

        st.markdown('''
                    Die Erzeugungseffizienz gibt an, wie viel Prozent der installierten Leistung tatsächlich erzeugt wird.
                    Dieser Wert kann je nach Wetterbedingungen variieren.
                    Die Simulation berechnet einen erwarten Wert für das Jahr 2030.
                    Mit den Slidern kann dieser Wert prozentual nach oben oder unten angepasst werden.
                    ''')
        with st.expander(label="Wie beeinflusst dieser Parameter die Simulation?"):
            st.caption('''
                    Die Effizienz ist ein Kennwert, welcher in der Simulation eine Vielzahl von Faktoren berücksichtigt.
                    So beeinflusst der Faktor die simulierte Wetterbedingungen, die Anzahl der Sonnenstunden, die Anzahl der Windstunden, die Anzahl der Wolkenstunden, etc.
                    Daher dient dieser Wert als Prozentuale Angabe, mit Abweichung vom simulierten wahrscheinlichen Referenzjahr in 2030.
                    ''')

        select_consumption_mode = st.selectbox(
            label="Berechnungsgrundlage",
            options=[
                "Gesamter Stromverbrauch (pauschal)",
                "Stromverbrauch basierend auf Parametern",
            ],
        )

        if select_consumption_mode == "Gesamter Stromverbrauch (pauschal)":
            st.caption('''
                    Der gesamte Stromverbrauch wird pauschal festgelegt.
                    ''')

            cols_consumption_simple = st.columns(2, gap='medium')

            with cols_consumption_simple[0]:
                st.number_input(
                    label="Gesamter Stromverbrauch [TWh]",
                    min_value=0,
                    max_value=1_000,
                    value=500,
                )
        elif select_consumption_mode == "Stromverbrauch basierend auf Parametern":
            st.caption('''
                    Der gesamte Stromverbrauch wird mittels Parametern berechnet.
                    Die Parameter werden in Verbrauchszahlen extrapoliert.
                    ''')

            cols_consumption_params = st.columns([1, 2], gap='medium')

            with cols_consumption_params[0]:
                st.slider(
                    label="E-Mobilität [Millionen]",
                    min_value=5,
                    max_value=30,
                    value=15,
                    help="Ziel E-Mobilität in 2030 beträgt 15 Millionen.",
                )

                number_heatpumps = st.number_input(
                    label="Wärmepumpen [Tausend]",
                    min_value=0,
                    max_value=2_000,
                    value=500,
                    help="Ziel Wärmepumpenzubau pro Jahr bis 2030 beträgt 500 Tausend.",
                )

                st.caption(f'Vorraussichtlicher Zubau pro Jahr: {(number_heatpumps * 1_000):,} Stück')

            with cols_consumption_params[1]:
                select_consumption_industry = st.selectbox(
                    label="Industrieverbrauch",
                    options=[
                        "Abnahme (97%)",
                        "Kein Wachstum (100%)",
                        "(Erwartet) Geringes Wachstum (103%)",
                        "Mittleres Wachstum (108%)",
                        "Hohes Wachstum (110%)",
                    ],
                    index=2,
                    help="Der Industrieverbrauch wird basierend auf den Daten des Fraunhofer ISE berechnet.",
                )

                if select_consumption_industry == "Abnahme (97%)":
                    st.caption('''
                            Der Industrieverbrauch reduziert sich in etwa auf 267 TWh.
                            ''')
                elif select_consumption_industry == "Kein Wachstum (100%)":
                    st.caption('''
                            Der Industrieverbrauch bleibt in etwa gleich und beträgt 276 TWh.
                            ''')
                elif select_consumption_industry == "(Erwartet) Geringes Wachstum (103%)":
                    st.caption('''
                            Der Industrieverbrauch wächst leicht und beträgt 284 TWh.
                            ''')
                elif select_consumption_industry == "Mittleres Wachstum (108%)":
                    st.caption('''
                            Der Industrieverbrauch wächst moderat und beträgt 291 TWh.
                            ''')
                elif select_consumption_industry == "Hohes Wachstum (110%)":
                    st.caption('''
                            Der Industrieverbrauch wächst stark und beträgt 294 TWh.
                            ''')

    def render_storage_view(self):
        st.markdown('#### 🔋 Speicher')

        st.multiselect(
            label="Auswahl der Speichertechnologien",
            options=[
                "Batteriespeicher",
                "Power-to-Gas (Wasserstoff)",
                "Power-to-Gas (Methanol)",
                "Power-to-Liquid (E-Fuels)",
                "Pumpspeicher",
            ],
            default=["Batteriespeicher"],
            help="Speicher können die Energieproduktion und den Energieverbrauch ausgleichen.",
        )

        View.image(
            URLImage(
                url="https://www.bmp-greengas.com/wp-content/uploads/2023/02/180426_bmp_PtG_InfoGrafik_2english-legende-2023-2.jpg",
                alt="Power-to-Gas Infografik",
            )
        )

        st.markdown('''
                    #### Was ist was?
                    ''')

        st.markdown('''
                    <div style="font-size: 1rem; font-weight: 700;">
                    🔋 Batteriespeicher
                    </div>

                    <div style="margin-left: 0rem; font-size: 0.8rem;">
                        Batteriespeicher können/müssen zur Netzstabilisierung eingesetzt werden.
                        Allerdings sind Batteriespeicher teuer und haben eine begrenzte Lebensdauer.
                        Daher ist es unwahrscheinlich, dass Batteriespeicher in großem Umfang eingesetzt werden,
                        um langfristig große Mengen an Energie zu speichern.
                    </div>
                    </br>
                    ''', unsafe_allow_html=True)

        st.markdown('''
                    <div style="font-size: 1rem; font-weight: 700;">
                    Power-to-Gas (Wasserstoff) - H<sub>2</sub>
                    </div>

                    <div style="margin-left: 0rem; font-size: 0.8rem;">
                        Power-to-Gas Anlagen können große Mengen an Energie speichern.
                        Strom wird in Wasserstoff umgewandelt und kann bei Bedarf
                        in Kraftwerken verbrannt werden, um Strom zu erzeugen.
                        Die Umwandlung von Wasserstoff in Strom ist allerdings ineffizient.
                        Während der Umwandlung geht ein Großteil der Energie verloren,
                        sodass von 100% eingespeister Energie nur in etwa 77% wieder zurückgewonnen werden können.
                    </div>
                    </br>
                    ''', unsafe_allow_html=True)

        st.markdown('''
                    <div style="font-size: 1rem; font-weight: 700;">
                    Power-to-Gas (Methanol) - CH<sub>3</sub>OH
                    </div>

                    <div style="margin-left: 0rem; font-size: 0.8rem;">
                        Power-to-Gas Anlagen können große Mengen an Energie speichern.
                        Wasserstoff wird weiter in Methanol umgewandelt und kann in das Erdgasnetz eingespeist werden.
                        Die Umwandlung von Strom in Wasserstoff und weiter in Methanol und wieder in Strom ist allerdings ineffizient.
                        Während der Umwandlung geht ein Großteil der Energie verloren,
                        sodass von 100% eingespeister Energie nur in etwa 50-60% wieder zurückgewonnen werden können.
                    </div>
                    </br>
                    ''', unsafe_allow_html=True)

        st.markdown('''
                    <div style="font-size: 1rem; font-weight: 700;">
                    ⛽ Power-to-Liquid (E-Fuels) - C<sub>x</sub>H<sub>x</sub>
                    </div>

                    <div style="margin-left: 0rem; font-size: 0.8rem;">
                        Power-to-liquid ist ein Sammelbegriff für verschiedene synthetische Kraftstoffe.
                        Dazu gehören die bekannten eFuel Kraftstoffe wie eMethanol, eDiesel und eKerosin.
                        Basierend auf dem Power-to-Gas Verfahren wird Wasserstoff in Methanol umgewandelt.
                        Durch das Beifügen von weiteren synthetischen Komponenten entsteht ein Kraftstoff,
                        der wie ein herkömmlicher Kraftstoff verwendet werden kann.
                        Dieser Prozess ist sehr ineffizient und benötigt viel Energie.
                        <b>Daher bleiben aus 100% eingespeister Energie nur in etwa 13% übrig.</b>
                    </div>
                    </br>
                    ''', unsafe_allow_html=True)

        st.markdown('''
                    <div style="font-size: 1rem; font-weight: 700;">
                    Pumpspeicher
                    </div>

                    <div style="margin-left: 0rem; font-size: 0.8rem;">
                        Pumpspeicher sind große Wasserbecken, in denen Wasser gepumpt werden kann.
                        Bei Bedarf kann das Wasser wieder abgelassen werden, um Strom zu erzeugen.
                        Pumpspeicher sind sehr effizient und können große Mengen an Energie speichern.
                        Allerdings sind Pumpspeicher sehr teuer und benötigen viel Platz.
                        Zudem ist die Höhe des Speicherbeckens proportional zur gespeicherten Energie.
                        Daher sind Pumpspeicher nur in bestimmten Regionen möglich.
                    </div>
                    ''', unsafe_allow_html=True)

    def render_footer_view(self):
        st.divider()


if __name__ == "__main__":
    view = Szenarien_View()
    view.render()
