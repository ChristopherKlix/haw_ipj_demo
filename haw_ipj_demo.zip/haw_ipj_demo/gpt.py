import openai
import os


def main():
    # Replace 'your-api-key' with your actual API key

    # Get api key from env
    global api_key
    api_key = os.environ.get('OPENAI_API_KEY')

    openai.api_key = api_key

    # Your prompt to the AI model
    prompt = "Can you say hi?"
    # prompt = "Provide the average sunshine hours in Germany per month."

    print('Talking to GPT...')

    # Make a request to the API
    response = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",
        messages=[
            {"role": "system", "content": "You are a scientific assistant, skilled in explaining complex concepts with creative flair."},
            {"role": "user", "content": "Hello, can you help me with our university project regaarding renewable energies?"}
        ],
        max_tokens=150
    )

    # Extract and print the AI's response
    ai_response = response.choices[0].message.content
    print(f'GPT: {ai_response}')


def ask(prompt: str):
    openai.api_key = api_key

    print('Talking to GPT...')
    print(f'Prompt: {prompt}')

    response = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",
        messages=[
            {
                "role": "system",
                "content": """
                You are a scientific assistant, skilled in explaining complex concepts with very few words. You are brief in your responses and don't hassitate to provide specific numbers. Your answer are always in German and every question is in the context of renewable energies in Germany.
                Erneuerbare Energien machen derzeit ca. 46,2% der Stromerzeugung in Deutschland aus.
                Erneuerbare Energien haben 2022 370 TWh in Deutschland erzeugt.
                Netto-Bilanz
                Gesamte Veränderung der Energieproduktion und des Energieverbrauchs in 2022 im Vergleich zum Vorjahr.
                ☀️🌊 Erneuerbare Energien: 233 TWh (8 TWh)
                ⛽🪨 Fossile Brennstoffe: 216 TWh (1 TWh)
                ⚡ Gesamtproduktion: 629 TWh (-40 TWh)
                🔌 Gesamtladung: 482 TWh (-22 TWh)

                Relative Bilanz
                Relative Veränderung der Energieproduktion und des Energieverbrauchs von 2021 bis 2022 im Vergleich zur Veränderung in den Vorjahren.
                ☀️🌊 Erneuerbare Energien: -2.6% (-5.7%)
                ⛽🪨 Fossile Brennstoffe: 0.46% (13.15%)
                ⚡ Gesamtproduktion: -5.97% (0.6%)
                🔌 Gesamtladung: -4.36%

                If you need to know the net balance of a year you can return the function name calculate_net_balance(year: int, metric_prefix: str, round_to: int) -> dict which returns a dictionary with the keys 'total-renewables', 'total-fossil-fuels', 'total-production' and 'total-load' and the values as floats.
                 """
            },
            {
                "role": "user",
                "content": prompt
            }
        ],
        max_tokens=150,
        n=1,
    )

    print(response)

    return response.choices[0].message.content


if __name__ == '__main__':
    main()
